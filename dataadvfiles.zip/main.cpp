#include <iostream>
#include "dataAdv.h"
#include "dreadcpp.h"
using namespace std;
DATA file;
data f;
int main()
{
	file = LOAD("inp");
	cout << RINT(file,1,1) << endl;
	UNLOAD(file);
	file = LOAD("inp2");
	cout << RINT(file,1,1) << endl;
	UNLOAD(file);

	DATA* v = new DATA;
	
	*v = LOAD("inp");
	cout << RINT(*v,1,1) << endl;
	UNLOAD(*v);

	f.load("inp");
	cout << f.i(1,1) << endl;
	f.unload();
	
	f.load("inp2");
	cout << f.i(1,1) << endl;
	f.unload();
	return 0;
}
